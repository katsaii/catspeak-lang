Thank you for downloading this library!
 /(.U w U.) b

Catspeak is developed by Kat (@katsaii)

Please include credit to Kat (homepage: https://nuxiigit.github.io/) if your project uses this product, as detailed in LICENSE.txt

Website: https://github.com/NuxiiGit/catspeak-lang
Online Documentation: https://github.com/NuxiiGit/catspeak-lang/wiki

To install, drag and drop the .yymps file from this directory onto the GMS2 IDE containing your project
Further information can be found on the official GameMaker manual: https://manual.yoyogames.com/IDE_Tools/Local_Asset_Packages.htm